package com.pinsettings.app

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

/** Do alag PIN: APP (4 digit, app kholne ke liye) aur GUARD (12 digit, Original Settings lock ke liye). */
object PinStore {

    const val APP = "app"
    const val GUARD = "guard"

    fun len(kind: String): Int = if (kind == APP) 4 else 12

    private fun prefs(c: Context, kind: String) =
        c.getSharedPreferences("pin_$kind", Context.MODE_PRIVATE)

    private fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest("$salt:$pin".toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun isSet(c: Context, kind: String): Boolean =
        prefs(c, kind).getString("hash", null) != null

    fun save(c: Context, kind: String, pin: String) {
        val salt = UUID.randomUUID().toString()
        prefs(c, kind).edit()
            .putString("salt", salt)
            .putString("hash", hash(salt, pin))
            .putInt("fails", 0)
            .putLong("until", 0L)
            .apply()
    }

    fun clear(c: Context, kind: String) {
        prefs(c, kind).edit().clear().apply()
    }

    /** Kitne millisecond baad dobara try kar sakte ho (0 = abhi kar sakte ho). */
    fun waitMs(c: Context, kind: String): Long =
        (prefs(c, kind).getLong("until", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    fun check(c: Context, kind: String, pin: String): Boolean {
        if (waitMs(c, kind) > 0L) return false
        val p = prefs(c, kind)
        val salt = p.getString("salt", null) ?: return false
        if (hash(salt, pin) == p.getString("hash", null)) {
            p.edit().putInt("fails", 0).putLong("until", 0L).apply()
            return true
        }
        val fails = p.getInt("fails", 0) + 1
        val e = p.edit().putInt("fails", fails)
        if (fails % 5 == 0) {
            val step = (fails / 5 - 1).coerceAtMost(5)
            e.putLong("until", System.currentTimeMillis() + 30_000L * (1L shl step))
        }
        e.apply()
        return false
    }

    /** Purana (v7 tak) ek hi PIN: 4 digit = App PIN, 12 digit = Settings PIN ban jata hai. */
    fun migrate(c: Context) {
        val old = c.getSharedPreferences("pin_store", Context.MODE_PRIVATE)
        val h = old.getString("hash", null) ?: return
        val salt = old.getString("salt", null) ?: return
        val len = if (old.contains("len")) old.getInt("len", 12) else 4
        val kind = if (len == 4) APP else GUARD
        if (!isSet(c, kind)) {
            prefs(c, kind).edit().putString("salt", salt).putString("hash", h).apply()
            if (kind == APP) {
                c.getSharedPreferences("app", Context.MODE_PRIVATE)
                    .edit().putBoolean("app_lock", true).apply()
            }
        }
        old.edit().clear().apply()
    }
}
