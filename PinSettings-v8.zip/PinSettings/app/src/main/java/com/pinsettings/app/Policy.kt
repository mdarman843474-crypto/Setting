package com.pinsettings.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

/** Device owner status aur hatana. */
object Policy {

    private fun dpm(c: Context): DevicePolicyManager =
        c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)

    fun isOwner(c: Context): Boolean =
        try {
            dpm(c).isDeviceOwnerApp(c.packageName)
        } catch (e: Exception) {
            false
        }

    /** Settings lock hatakar device owner hata deta hai. */
    fun release(c: Context): Boolean =
        try {
            SettingsGuard.disable(c)
            dpm(c).clearDeviceOwnerApp(c.packageName)
            try {
                dpm(c).removeActiveAdmin(admin(c))
            } catch (e: Exception) {
                // koi baat nahi
            }
            true
        } catch (e: Exception) {
            false
        }
}
